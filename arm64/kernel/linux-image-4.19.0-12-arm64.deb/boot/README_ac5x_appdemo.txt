Follow below steps before running appDemo on ac5x:

sudo su
cd /boot
mkimage -f sonic_fit_appdemo.its sonic_arm64_appdemo.fit 
reboot and stop at u-boot prompt

#### get the fit_name
Marvell>> printenv fit_name 
fit_name=image-HEAD.0-dirty-20220106.131541/boot/sonic_arm64.fit

#### Use the same path and modify to appdemo fit image 
Marvell>> setenv fit_name "image-HEAD.0-dirty-20220106.131541/boot/sonic_arm64_appdemo.fit"

#### confirm the setenv
Marvell>> printenv fit_name 
fit_name=image-HEAD.0-dirty-20220106.131541/boot/sonic_arm64_appdemo.fit

#### boot sonic
Marvell>> run sonic_image_1

